﻿using APPLib.Services.Interfaces;
using APPModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace APPLib.Services.Implementation
{
   // public class QualityPointImplementation 
    //{
    //    public float GPA { get; set; }
    //    public float GradePointAverage(List<Course> courses)
    //    {
    //        if (courses.Count > 0)
    //        {
    //            int totalQualityPoint = 0;
    //            int totalGradeUnit = 0;

    //            for(int i = 0; i < courses.Count; i++)
    //            {
    //                totalQualityPoint += courses[i].CourseUnit;
    //                totalGradeUnit += courses[i].ScoreDetails.Point;

    //            }
    //            GPA = totalQualityPoint / totalGradeUnit;
    //        }
    //        return GPA;
    //    }
    //}
}
