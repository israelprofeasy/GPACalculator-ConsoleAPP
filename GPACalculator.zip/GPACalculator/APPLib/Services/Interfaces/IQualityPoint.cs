﻿using APPModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace APPLib.Services.Interfaces
{
    interface IQualityPoint
    {
      //  public float GradePointAverage(List<Course> courses);
    }
}
