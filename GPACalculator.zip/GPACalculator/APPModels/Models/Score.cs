﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APPModels.Models
{
   public class Score
    {
        public char Grade { get; set; }
        public byte Point { get; set; }
        public string Remarks { get; set; }
       
    }
}
