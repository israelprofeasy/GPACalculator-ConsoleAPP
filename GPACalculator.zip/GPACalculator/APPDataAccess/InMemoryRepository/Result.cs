﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APPModels.Models
{
    public static class Result
    {
        public static float GPA { get; set; }
        public static List<Course> Courses { get; set; } = new List<Course>();

    }
}
